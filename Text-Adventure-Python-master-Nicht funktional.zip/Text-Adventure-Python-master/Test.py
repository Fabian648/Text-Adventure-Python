import os
import regex as re

print(__name__)
"""
a = os.listdir("Saved_Games/")
#regex = re.search(r"", a)

if buffer in re.findall(r"(?<=Config_TA_)[A-z]+(?=\.ini)", str(os.listdir("Saved_Games/"))):

for i in a:
    # print(i)
    #  "Config_TA_" + name + ".ini")
    print(i)
    x = re.findall(r"(?<=Config_TA_)[A-z]+(?=\.ini)", i)
    print(x)

print(a)
"""

