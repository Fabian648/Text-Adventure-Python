# werde ich noch anpassen
# Noch nicht bearbeitet oder funktional für das Spiel
class Logger:

    def __init__(self):
        pass

    def log(self, logtext):
        with open(os.path.join(os.getcwd(), "../BackupTest/full_log.txt"), "a") as logfile:
            logfile.write(logtext)


class DateTimeGetter:

    def __init__(self):
        import time
        self.time = time

    def date_getter(self):
        time = self.time
        return str(time.localtime().tm_year) + "-" + str(time.localtime().tm_mon)

    def time_getter(self):
        time = self.time
        return (str(time.localtime().tm_mday) + "_" + str(time.localtime().tm_hour) + "-" +
                str(time.localtime().tm_min) + "-" + str(time.localtime().tm_sec))


class Backup:

    def __init__(self, new_data, backup_data):
        self.dater = DateTimeGetter()
        self.logger = Logger()
        self.originalfile = new_data
        self.backuploc = backup_data

    def checkdir(self):

        # Momentaner Monat und Jahr
        date = str(self.dater.date_getter())

        # Boolean ob der Ordner Existiert
        pfaddir = os.path.join(self.backuploc, date)
        self.pfaddir = pfaddir
        check = os.path.isdir(pfaddir)

        #Wenn er exsistiert dann pass wenn nicht wird erstellt und nochmal getestet
        if check:
            #self.logger.log("dir found\n")
            True
        elif not check:
            self.logger.log("dir not found in " + pfaddir + ", ")
            os.mkdir(pfaddir)
            self.logger.log("dir made, ")
            backup.checkdir()
        else:
            self.logger.log("Unexpected Error in Backup.checkdir()\n")
            sys.exit("Fehler in checkdir")

    def checkfil(self):

        # Überprüfung ob es die datei zum backup überhaupt gibt
        boolean = os.path.isfile(self.originalfile)
        if boolean:
            #self.logger.log("Vocabulary_List found, ")
            True
        elif not boolean:
            self.logger.log("Vocabulary_List not found, ")
        else:
            self.logger.log("Unexpected Error in Backup.checker()\n")
            sys.exit("Kritischer Fehler bei checkfil")

        #Filename ersteller
        time = str(self.dater.time_getter())
        pfadfil = os.path.join(self.pfaddir + "\\" + time + ".txt")

        #Backup Ersteller
        with open(pfadfil, "x") as backupfile:
            with open(self.originalfile) as originfile:
                for i in originfile:
                    backupfile.write(i)

        self.logger.log("Backup erstellt\n")


if __name__ == "__main__":
    import sys
    import os

    #Pfade für die Vocab List und des über ordners für die Backups
    vocabfile = r"C:\Users\Ben\Desktop\Berufsschule\Englisch\Vocab\Vocabulary_List.txt"
    backuplocation = r"C:\Users\Ben\Desktop\Berufsschule\Englisch\Vocab\Vocab_List_Backup"

    backup = Backup(vocabfile, backuplocation)
    backup.checkdir()
    backup.checkfil()
    print("Backup Erstellt")

